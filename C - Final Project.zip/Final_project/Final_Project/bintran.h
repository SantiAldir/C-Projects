#ifndef BINTRAN_H_
#define BINTRAN_H_

#define MOV 0
#define CMP (MOV+1)
#define ADD (CMP+1)
#define SUB (ADD+1)
#define LEA (SUB+1)
#define CLR (LEA+1)
#define NOT (CLR+1)
#define INC (NOT+1)
#define DEC (INC+1)
#define JMP (DEC+1)
#define BNE (JMP+1)
#define RED (BNE+1)
#define PRN (RED+1)
#define JSR (PRN+1)
#define RTS (JSR+1)
#define STOP (RTS+1)
#define LABELSIZE 31
#define SENTENCESIZE 80
#define COMMANDSIZE 4

#include "sentenceanalysis.h"

struct Label
/** a struct to represent the Labels*/
{
	char name[LABELSIZE];
	int labelnum;
	int internal;
};
struct ErrorMessage
/**a struct to represent error massages*/
{
	char wrong[200];
	int line;
};
struct Word
/**a struct to represent a word*/
{
	char word[15];
};
struct CompleteWord
/**a struct to represent the complete word with the word number*/
{
	struct Word word;
	int wordnumber;
};

int opCode(char[]);
int opDel(struct OrderingSentence, int);




#endif /* BINTRAN_H_ */
