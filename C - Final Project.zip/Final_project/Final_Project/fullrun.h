/*
 * fullrun.h
 *
 *  Created on: Mar 27, 2020
 *      Author: user
 */

#ifndef FULLRUN_H_
#define FULLRUN_H_
#include "bintran.h"
#include "extendedstring.h"
#include "sentenceanalysis.h"
#define MAXLABELS 200
#define MAXWORDS 4096

struct Label labels[MAXLABELS];
struct ErrorMessage errors[MAXWORDS];
struct CompleteWord Words[MAXWORDS];
int errorAmount=0;
int wordsAmount=0;

int inLabels(char[]);
int min(int, int);
int max(int, int);
#endif /* FULLRUN_H_ */
