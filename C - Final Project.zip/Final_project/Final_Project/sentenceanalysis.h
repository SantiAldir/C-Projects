/*
 * sentenceanalysis.h
 *
 *  Created on: Mar 20, 2020
 *      Author: user
 */

#ifndef SENTENCEANALYSIS_H_
#define SENTENCEANALYSIS_H_

#include "bintran.h"

struct OrderingSentence
/** a struct to represent Ordering sentences by their parts*/
{
	char command[COMMANDSIZE];
	char fstOp[SENTENCESIZE];
	char secOp[SENTENCESIZE];
	char label[LABELSIZE];
};
struct GuidingSentence
/**a struct to represent a guiding sentence*/
{
	char guidence[SENTENCESIZE];
	char input[SENTENCESIZE];
	char label[LABELSIZE];
};

int isLabeled(char[]);
int labelSize(char[]);
void isolateLabel(char*,char*);
void removeLabel(char*, char*);
int sentenceType(char[]);
int amountOfOperands(char[]);
struct OrderingSentence isolatePartsOfOrderingSentence(char[]);
struct GuidingSentence isolatePartsOfGuidingSentence(char[]);
int isRegister(char[]);

#endif /* SENTENCEANALYSIS_H_ */
