/*
 * sentenceanalysis.c
 *
 *  Created on: Mar 20, 2020
 *      Author: user
 */

#ifndef SENTENCEANALYSIS_C_
#define SENTENCEANALYSIS_C_
#include "sentenceanalysis.h"
#include <string.h>
#include "bintran.h"
#include "extendedstring.h"


int isLabeled(char phrase[])
/**
 * a method to check if the phrase is with a label on the start
 * @param phrase[] the phrase tested
 * @return 1 if the phrase is with a label, 0 otherwise*/
{
	int loc=0;
	while(phrase[loc]!='\0')
	{
		if(phrase[loc]==':')
			return 1;
		loc++;
	}
	return 0;
	}
int labelSize(char phrase[])
/**
 * this method checks the size of the label in a given phrase
 * @param phrase the full sentence  to check
 * @return the size of the label, 0 if there is no label*/
{
	int count=0;
	if (isLabeled(phrase)==0)
		return 0;
	while (phrase[count]!=':')
		count++;
	return count;
	}
void isolateLabel(char *phrase,char *label)
/**
 * a function which isolates the label of the phrase
 * @param phrase the phrase to find the label
 * @param label the string to receive the label*/
{
	int lasi=labelSize(phrase);//the size of the label of the phrase
	if (isLabeled(phrase)==0)
	{
		label=strcpy(label,"");
	}
	else
	{
			label=strncpy(label,phrase,lasi);
		}
	}
void removeLabel(char *phrase, char *newphrase)
/**
 * a function to remove the label from the full sentence
 * @param phrase the full phrase
 * @param newphrase the string to receive the new phrase without the label*/
{
	int lasi=labelSize(phrase);
	int i=0;
	if(lasi==0)
		newphrase=strcpy(newphrase,phrase);
	lasi++;
	while (phrase[lasi]==' ' || phrase[lasi]=='\t')
	{
		lasi++;
	}
	for (i=0;i<strlen(phrase);i++)
	{
		newphrase[i]=phrase[lasi+i];
	}
	newphrase[i+1]='\0';
	}
int sentenceType(char phrase[])
/**
 * a function to find the type of the sentence
 * @param phrase the sentence to check
 * @return 1 if guiding sentence, 2 if ordering sentence
 * and 0 if the sentence isn't a proper sentence*/
{
	char checkedphrase[81];
	char com[4];
	removeLabel(phrase, checkedphrase);
	com[0]=subString(checkedphrase, com, ' ');
	if(checkedphrase[0]=='.')
	{
		return 1;
	}
	if (strEquals(com, "stop")==1||opCode(com)!=-1)
		return 2;
	return 0;
	}
int amountOfOperands(char phrase[])
/**
 * a function to count how many operands are there in a given sentence
 * @param phrase the given sentence
 * @return the amount of operands in the sentence, if the sentence is not
 * an ordering sentence it will return -1 */
{
	char checkphrase[81];
	int aoc=0, i=0;
	removeLabel(phrase, checkphrase);
	if (sentenceType(phrase)!=2)
		return -1;
	if(opCode(phrase)!=-1)
	{
		return 0;
	}
	while(phrase[i]!='\0')
	{
		if(phrase[i]==',')
			{
			aoc++;
			}
		i++;
	}
	return aoc+1;
	}
struct OrderingSentence isolatePartsOrderingSentence(char phrase[])
/**
 * a function to analyze an ordering sentence and return it by it's parts
 * @param phrase is the sentence
 * @return a struct of type OrderingSentence*/
{
	struct OrderingSentence os={"","","",""};
	char label[LABELSIZE];
	char reducedphrase[SENTENCESIZE];
	char com[COMMANDSIZE];
	char fstop[SENTENCESIZE];
	char secop[SENTENCESIZE];
	int counter=0;
	int opcounter=0;
	if (sentenceType(phrase)!=2)
	{
		return os;
	}
	isolateLabel(phrase, label);
	removeLabel(phrase,reducedphrase);
	while(reducedphrase[counter]!=' '&&reducedphrase[counter]!='\t')
	{
		com[counter]=reducedphrase[counter];
		counter++;
	}
	com[counter]='\0';
	if(amountOfOperands(reducedphrase)>0&&amountOfOperands(reducedphrase)<3)
	{
		if(amountOfOperands(reducedphrase)==2)
		{
			while (reducedphrase[counter]!=',')
			{
				if(reducedphrase[counter]!=' '&&reducedphrase[counter]!='\t')
				{
					fstop[opcounter]=reducedphrase[counter];
					opcounter++;
				}
				counter++;
			}
			fstop[opcounter]='\0';
			opcounter=0;
		}
		while (counter<strlen(reducedphrase))
		{
			if(reducedphrase[counter]!=' ' && reducedphrase[counter]!='\t')
			{
				secop[opcounter]=reducedphrase[counter];
				opcounter++;
			}
			counter++;
		}
		secop[opcounter]='\0';
	}
	strcpy(os.command,com);
	strcpy(os.fstOp,fstop);
	strcpy(os.secOp,secop);
	strcpy(os.label,label);
	return os;
}
struct GuidingSentence isolatingPartsOfGuidingSentence(char phrase[])
/**
 * a function to isolate the parts  of guiding sentence
 * @param phrase the sentence the function receives
 * @return the sentence in parts*/
{
	struct GuidingSentence gs={"","",""};
	char guidence[80];
	char input[80];
	char label[80];
	char reducedphrase[80];
	removeLabel(phrase,reducedphrase);
	isolateLabel(phrase,label);

	int counter=0;
	int i=0;
	int sflag=0;
	while(reducedphrase[counter]!=' '&&reducedphrase[counter]!='\t')
	{
		guidence[counter]=reducedphrase[counter];
		counter++;
	}
	guidence[counter]='\0';
	if(strEquals(guidence, ".string")!=0)
	{
		sflag=1;
	}
	while(reducedphrase[counter]==' '||reducedphrase[counter]=='\t')
	{
		counter++;
	}
	while (reducedphrase[counter]!='\0')
	{
		if((reducedphrase[counter]!=' '&&reducedphrase[counter]!='\t')||sflag==1)
		{
			input[i]=reducedphrase[counter];
			i++;
		}
		counter++;
	}
	counter=0;
	if(sflag==1)
	{
		for(int i=0; i<strlen(input);i++)
		{
			if(input[i]=='"')
			{
				counter++;
			}
		}
		if(counter!=2)
		{
			strcpy(input, "");
		}
	}
	strcpy(gs.guidence, guidence);
	strcpy(gs.input, input);
	strcpy(gs.label, label);
	return gs;
	}
int isRegister(char op[])
/**a function to check if a given operand is a register
 * @param op the given operand
 * @return 1 if is register. 0 otherwise*/
{
	if(op[0]=='r' && ZERO <= op[1] && op[1] <= SEVEN)
	{
		return 1;
	}
	return 0;
	}

#endif /* SENTANCEANALYSIS_C_ */
