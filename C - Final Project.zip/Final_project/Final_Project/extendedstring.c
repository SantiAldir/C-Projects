/*
 * extendedstring.c
 *
 *  Created on: Mar 20, 2020
 *      Author: user
 */

#ifndef EXTENDEDSTRING_C_
#define EXTENDEDSTRING_C_
#include "extendedstring.h"
#include <string.h>

int strEquals(char s1[], char s2[])
/**
 * function to compare if 2 string are the same
 * @param s1 first string to compare
 * @param s2 second string to compare
 * @return 1 if the strings are equals, 0 otherwise*/
{
	int len1= strlen(s1),len2=strlen(s2);
	int i;
	if(len1!=len2)
		return 0;
	for (i=0;i<len1;i++)
	{
		if (s1[i]!=s2[i])
			return 0;
	}
	return 1;
	}
char *subString(char *str, char *nstr, char s)
/**
 * a function to create a substring from a certain string to the first
 * show of a given character
 * @param str the given string
 * @param nstr the new sub string
 * @param s the character to stop the substring before
 * @return a substring of the first string*/
{
	int count=0;
	while (str[count]!=s &&count<strlen(str))
	{
		count++;
	}
	nstr=strncpy(str,nstr, count);
	return *nstr;
	}
char toLowerChar(char c)
/**
 * a method which retrieves a character and if it's a letter,
 * it return the lower case of the character
 * @param c the given letter
 * @return the lower case of c and c itself if not a letter*/
{
	if ('A'<=c && c<='Z')
		return c-UPPERLOWERDIFFER;
	return c;
	}
void combineStrings(char *s1, char *s2, char*s3)
/**
 * a function which receives 2 strings and unite them to a third given string
 * @param s1 the first string to combine
 * @param s2 the second string to combine, will start right where s1 ends
 * @param s3 the final combined string*/
{
	int l1= strlen(s1);
	int l2= strlen(s2);
	int i;
	for(i=0;i<l1;i++)
	{
		s3[i]=s1[i];
	}
	for(i=0;i<l2;i++)
	{
		s3[l1+i]=s2[i];
	}
	s3[l1+l2]='\0';
	}
int isDigit(char n)
/**a function to test if a given character is digit
 * @param n the tested character
 * @return 1 if the character is digit, 0 otherwise*/
{
	if (ZERO <= n && NINE >= n)
	{
		return 1;
	}
	return 0;
	}
int isNumber(char s[])
/**a function to check if a given string is a number
 * @param s the string to test
 * @return 1 if is a number, 0 otherwise*/
{
	int len=strlen(s);
	int ans=0;
	int loc=0;
	int sign=0;
	if(s[loc]=='-' || s[loc]=='+')
	{
		sign++;
	}
	for(;loc<len;loc++)
	{
		ans+=isDigit(s[loc+sign]);
	}
	if (ans==len-sign)
	{
		return 1;
	}
	return 0;
	}
void removeNChar(char *s1, int n, char *s2)
/**a function to remove the first n characters of given string.
 * does nothing if the length of s1 is lower or equal to n
 * @param s1 the given string
 * @param n the amount first characters to remove
 * @param s2 the string to receives the shortened string*/
{
	int i;
	if(strlen(s1)>n)
	{
	for (i=0; i<strlen(s1);i++)
	{
		s2[i]=s1[i+n];
	}
	s2[i]='\0';
	}
}
int translateDigit(char c)
/**a function to translate characters to digits
 * @param c the character to translate
 * @return the character as number*/
{
	switch (c)
	{
		case ZERO:
			return 0;
		case ONE:
			return 1;
		case TWO:
			return 2;
		case THREE:
			return 3;
		case FOUR:
			return 4;
		case FIVE:
			return 5;
		case SIX:
			return 6;
		case SEVEN:
			return 7;
		case EIGHT:
			return 8;
		case NINE:
			return 9;
		default:
			return -1;
	}
}
int translateNumber(char s[])
/**a function to translate given string to integer
 * @param s the given string
 * @return the string as integer*/
{
	int sum=0;
	int neg=1;
	int i=0;
	if (s[0]=='-' || s[0]=='+')
	{
		i++;
	}
	if (s[0]=='-')
	{
		neg*=-1;
	}
	for (; i<strlen(s);i++)
	{
		sum*=10;
		sum+=translateDigit(s);
	}
	sum*=neg;
	return sum;
	}
char dtoc(int d)
/**a function to convert a digit to a character of it's kind
 * @param d the digit to convert
 * @return d as char*/
{
	switch (d)
	{
		case 0:
			return ZERO;
		case 1:
			return ONE;
		case 2:
			return TWO;
		case 3:
			return THREE;
		case 4:
			return FOUR;
		case 5:
			return FIVE;
		case 6:
			return SIX;
		case 7:
			return SEVEN;
		case 8:
			return EIGHT;
		case 9:
			return NINE;
		default:
			return'\0';
	}
	}
int sizeOfNum(int num)
/**a function to find out the size of a given number
 * @param the given number
 * @return the amount of digits in this number*/
{
	int size=0;
	int anum=abs(num);
	while (anum!=0)
	{
		size++;
		anum/=10;
	}
	return size;
	}
char *itoa(int num)
{
	int anum=abs(num);
	char *snum;
	int sign=0;
	if (num<0)
	{
		sign=-1;
	}
	if (sign<-1)
	{
		snum[0]='-';
	}
	while (anum!=0)
	{
		snum[sizeOfNum(anum)-sign-1]=dtoc(anum%10);
		anum/=10;
	}
	return *snum;
	}
#endif /* EXTENDEDSTRING_C_ */
