/*
 * fullrun.c
 *
 *  Created on: Mar 27, 2020
 *      Author: user
 */

#ifndef FULLRUN_C_
#define FULLRUN_C_
#include "fullrun.h"
#include "bintran.h"
#include "extendedstring.h"
#include "sentenceanalysis.h"

int min(int n1, int n2)
/**function to find minimum of 2 integers
 * @param n1 the first number
 * @param n2 the second integer
 * @return the lower number*/
{
	if(n1<n2)
		return n1;
	return n2;
	}
int max(int n1, int n2)
/**function to find the bigger number of 2 numbers
 * @param n1 the first number
 * @param n2 the second number
 * @return the bigger number*/
{
	return -1*min(-1*n1, -1*n2);
	}
int inLabels(char label[])
/**a function to chaeck if a the name of a label is already in the code
 * @param label the label to check
 * @return the place in the list of labels of the program. return -1 if not*/
{
	int ans=-1;
	int i=0;
	while(strEquals(labels[i].name,"")!=1)
	{
		if(strEquals(label,labels[i].name))
		{
			ans=i;
		}
		i++;
	}
	return ans;
	}
#endif /* FULLRUN_C_ */
