/*
 * bintran.c
 *
 *  Created on: Mar 20, 2020
 *      Author: user
 */

#ifndef BINTRAN_C_
#define BINTRAN_C_
#include "bintran.h"
#include "sentenceanalysis.h"
#include "extendedstring.h"
#include "fullrun.h"
#include <math.h>
#include <string.h>



int opCode(char fp[])
/**a function to find the opCode of a given string
 * @param fp the given string
 * @return the value in decimal of fp. return -1 if it's not a proper command*/
{
	if(strEquals(fp,"mov")==1)
		return MOV;
	if(strEquals(fp,"cmp")==1)
		return CMP;
	if(strEquals(fp,"add")==1)
		return ADD;
	if(strEquals(fp,"sub")==1)
		return SUB;
	if(strEquals(fp,"lea")==1)
		return LEA;
	if(strEquals(fp,"clr")==1)
		return CLR;
	if(strEquals(fp,"not")==1)
		return NOT;
	if(strEquals(fp,"inc")==1)
		return INC;
	if(strEquals(fp,"dec")==1)
		return DEC;
	if(strEquals(fp,"jmp")==1)
		return JMP;
	if(strEquals(fp,"bne")==1)
		return BNE;
	if(strEquals(fp,"red")==1)
		return RED;
	if(strEquals(fp,"prn")==1)
		return PRN;
	if(strEquals(fp,"jsr")==1)
		return JSR;
	if(strEquals(fp,"rts")==1)
		return RTS;
	if(strEquals(fp,"stop")==1)
		return STOP;
	return -1;

}
int opDel(struct OrderingSentence os, int on)
/**a function to find the delivery method of an operand
 * in given ordering sentence
 * @param os the ordering sentence
 * @param on the number of the operand in the given ordering sentence
 * @return the delivery method of the operand. -1 if the operand is illegal
 * or 4 if there is no operand*/
{
	int delnum=-1;
	char op[SENTENCESIZE];
	if(on==1)
	{
		strcpy(op, os.fstOp);
	}
	else
	{
		strcpy(op, os.secOp);
	}
	if(strEquals(op,"")==1)
	{
		return 4;
	}
	if(op[0]=='#')
	{
		char op1[SENTENCESIZE-1];
		removeNChar(op,1,op1);
		if (isNumber(op1)==1)
		{
			delnum=0;
		}
	}
	else
	{
		if(inLabels(op)!=-1)
		{
			delnum=1;
		}
		else
		{
			int star=0;
			char op1[SENTENCESIZE];
			strcpy(op1,op);
			if(op[0]=='*')
			{
				star++;
			}
			removeNChar(op,star,op1);
			if(isRegister(op1)==1)
			{
				if(star==1)
				{
					delnum=2;
				}
				else
				{
					delnum=3;
				}
			}
		}
	}
	return delnum;
	}
struct Word firsWord(struct OrderingSentence os, int line)
{
	struct Word w={"000000000000000"};
	int oc=opCode(os.command);
	int op1=opDel(os, 1);
	int op2=opDel(os,2);
	w.word[2]='1';
	for (int i=3;i>=0;i--)
	{
		int n=pow(2,i);
		if(oc>n)
		{
			w.word[11+i]='1';
			oc-=n;
		}
	}
	if(0<=op1 && op1<=3)
	{
		w.word[7+op1]='1';
	}
	else
	{
		if (op1==-1)
		{
			strcpy(errors[errorAmount].wrong,strcat("problem with first operand in line " ,itoa (line)));
			errors[errorAmount].line=line;
			errorAmount++;
		}
	}
	if(0<=op2 && op2<=3)
	{
		w.word[3+op2]='1';
	}
	else
	{
		if(op2==-1)
		{
			strcpy(errors[errorAmount].wrong,strcat("probelem with second operand in line ", itoa(line)));
			errors[errorAmount].line=line;
			errorAmount++;
		}
	}
	return w;
	}
int isLegalOrderingSentence(struct OrderingSentence os)
/**a function that check if given ordering sentence is legal
 * @param os the given ordering sentence
 * @return -1 if there is a problem if there is an error with the sentence, 1 otherwise*/
{
	int oc= opCode(os.command);
	int op1=opDel(os,1);
	int op2=opDel(os,2);
	if (RTS<=oc&& STOP>=oc)
	{
		if (op1!=4 && op2!=4)
		{
			return -1;
		}
	}
	if(CLR<= oc && JSR>= oc)
	{
		if (op1!=4)
		{
			return -1;
		}
		if ((CLR<=oc &&DEC>=oc) || oc== RED)
		{
			if (op2<1 || op2>3)
			{
				return -1;
			}
		}
		if ((JMP<= oc && BNE>= oc)||oc==JSR)
		{
			if (op2<1 || op2>2)
			{
				return -1;
			}
		}
		if(oc==PRN)
		{
			if (op2<0 ||op2 >3)
			{
				return -1;
			}
		}
	}
	if(oc==LEA)
	{
		if(op1!=1)
		{
			return -1;
		}
		if(op2<1 || 3<op2)
		{
			return -1;
		}
	}
	if (MOV<=oc || oc<=SUB)
	{
		if (op1<0 || op1>3)
		{
			return -1;
		}
		if (oc== CMP)
		{
			if (op2<0 || op2>3)
			{
				return -1;
			}
		}
		if(op2<1 || op2 >3)
		{
			return -1;
		}
	}
	return 1;
}
void toBinary(int num, int bits, char *str)
/**converts num in dec to binary string
 * @param the number to convert
 * @param bits the amount of bits the number has
 * @param *str the string to contain the binary number*/
{
	int anum=abs(num);
	int sign=1;
	if (num<0)
	{
		sign=-1;
	}
	for (int i=bits;i>=0;i--)
		{
			int n=pow(2,i);
			if(num>n)
			{
				str[i]='1';
				num-=n;
			}
		}
	if( sign==-1)
	{
		for (int i=0;i<bits;i++)
		{
			if(str[i]==ZERO)
				str[i]=ONE;
			else
				str[i]=ZERO;
		}
		int i=0;
		while(str[i]!=ZERO)
		{
			str[i]=ZERO;
			i++;
		}
		str[i]=ONE;
	}
	}
void translaeOrderingSentence(struct OrderingSentence os, int line)
{
	struct Word fw={"000000000000000"};
	struct Word sw={"000000000000000"};
	struct Word tw={"000000000000000"};
	int op1=opDel(os,1);
	int op2=opDel(os, 2);
	int oc=opCode(os.command);
	int legal= isLegalOrderingSentence(os);
	if (legal !=1)
	{
		strcpy(errors[errorAmount].wrong,strcat(strcat("the ordering sentence in line ",itoa(line))," is illegal"));
		errors[errorAmount].line=line;
		errorAmount++;
	}
	else
	{
		if (op1==0)
		{
			char s[12];
			char checked[SENTENCESIZE];
			removeNchar(os.fstOp,1, checked);
			toBinary(translateNumber(checked),12, s);
			sw.word[2]=ONE;
			for(int i=0;i<12;i++)
			{
				sw.word[3+i]=s[i];
			}
		}
		if(op2==0)
		{
			char s[12];
			char checked[SENTENCESIZE];
			removeNchar(os.secOp,1, checked);
			toBinary(translateNumber(checked),12, s);
			tw.word[2]=ONE;
			for(int i=0;i<12;i++)
			{
				tw.word[3+i]=s[i];
			}
		}
		if (op1==1)
		{
			int lab=inLabels(os.fstOp);
			char s[12];
			toBinary(labels[lab].labelnum,12,s);
			if(labels[lab].internal==1)
			{
				sw.word[1]=ONE;
			}
			else
			{
				sw.word[2]=ONE;
			}
			for (int i=0;i<12;i++)
			{
				sw.word[3+i]=s[i];
			}
		}
		if (op2==1)
		{
			int lab=inLabels(os.secOp);
			char s[12];
			toBinary(labels[lab].labelnum,12,s);
			if(labels[lab].internal==1)
			{
				tw.word[1]=ONE;
			}
			else
			{
				tw.word[2]=ONE;
			}
			for (int i=0;i<12;i++)
			{
				tw.word[3+i]=s[i];
			}
		}
		if(2<=min(op1, op2) && max(op1,op2)<=3)
		{
			char binop1[3];
			char binop2[3];
			char *fixedop1;
			char *fixedop2;
			strcpy(fixedop1, os.fstOp);
			strcpy(fixedop2, os.secOp);
			if(fixedop1[0]=='*')
				removeNChar(fixedop1,1,fixedop1);
			if (fixedop2[0]=='*')
				removeNChar(fixedop2,1,fixedop2);
			toBinary(dotc(fixedop1[1]),3,binop1);
			toBinary(dotc(fixedop2[1]),3,binop2);
			for (int i=0;i<3;i++)
			{
				sw.word[3+i]=binop2[i];
				sw.word[6+i]=binop1[i];
			}
			sw.word[2]=ONE;
		}
		else
		{
			if (2<=op1&& op1<=3)
			{
				{
					char binop1[3];
					char *fixedop1;
					strcpy(fixedop1, os.fstOp);
					if(fixedop1[0]=='*')
						removeNChar(fixedop1,1,fixedop1);
					toBinary(dotc(fixedop1[1]),3,binop1);
					for (int i=0;i<3;i++)
					{
						sw.word[6+i]=binop1[i];
					}
					sw.word[2]=ONE;
				}
			}
			else
			{
				if (2<=op2 && op2<=3)
				{
					char binop2[3];
					char *fixedop2;
					strcpy(fixedop2, os.secOp);
					if (fixedop2[0]=='*')
						removeNChar(fixedop2,1,fixedop2);
					toBinary(dotc(fixedop2[1]),3,binop2);
					for (int i=0;i<3;i++)
					{
						tw.word[3+i]=binop2[i];
					}
					tw.word[2]=ONE;}
				}
			}
		}
	Words[wordsAmount].word=fw;
	Words[wordsAmount].wordnumber=wordsAmount;
	wordsAmount++;
	if(strEquals(sw.word,"000000000000000")==1)
	{
		Words[wordsAmount].word=sw;
		Words[wordsAmount].wordnumber=wordsAmount;
		wordsAmount++;
	}
	if(strEquals(tw.word,"000000000000000")==1)
	{
		Words[wordsAmount].word=tw;
		Words[wordsAmount].wordnumber=wordsAmount;
		wordsAmount++;
	}
	{}
	}

#endif /* BINTRAN_C_ */
