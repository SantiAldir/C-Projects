/*
 * extendedstring.h
 *
 *  Created on: Mar 20, 2020
 *      Author: user
 */

#ifndef EXTENDEDSTRING_H_
#define EXTENDEDSTRING_H_
#define UPPERLOWERDIFFER ('A'-'a')
#define ZERO '0'
#define ONE '1'
#define TWO '2'
#define THREE '3'
#define FOUR '4'
#define FIVE '5'
#define SIX '6'
#define SEVEN '7'
#define EIGHT '8'
#define NINE '9'
#include <string.h>

int strEquals(char[],char[]);
char *subString(char*, char*, char);
char toLowerChar(char);
void combieStrings(char*, char*, char*);
int isDigit(char);
int isNumber(char[]);
void removeNChar(char*,int,char*);
int translatDigit(char);
int translateNumber(char[]);
char dtoc (int);
int sizeOfNum(int);
char *itoa(int)
#endif /* EXTENDEDSTRING_H_ */
